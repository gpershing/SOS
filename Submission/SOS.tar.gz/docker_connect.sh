#!/bin/sh

docker run --rm -it -v `pwd`:/home/sos -w=/home/sos sheronw1174/sos-env:latest